# Create a system security report using lynis. Output the result to the console.

# Run a full system audit with lynis
sudo lynis audit system

# Note:
# - This command runs a comprehensive security audit of the system.
# - The results will be displayed in the console output.
# - Lynis requires root privileges to perform certain checks, hence 'sudo' is used.
# - The audit findings are also saved in the log files:
#     - Detailed log: /var/log/lynis.log
#     - Report data: /var/log/lynis-report.dat
# - You can review the log files for more detailed information after the audit.