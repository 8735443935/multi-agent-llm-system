import nmap

def detailed_scan(hosts):
    nm = nmap.PortScanner()
    detailed_results = {}
    
    for host in hosts:
        nm.scan(hosts=host, arguments='-p 80,443,8080 -sV -O')
        detailed_results[host] = nm[host]
    
    return detailed_results

hosts = ['10.11.1.1', '10.11.1.24', '10.11.1.33']
detailed_results = detailed_scan(hosts)

for host, result in detailed_results.items():
    print(f"Host: {host}")
    if 'tcp' in result:
        for port in result['tcp']:
            port_info = result['tcp'][port]
            print(f"  Port: {port}")
            print(f"    State: {port_info['state']}")
            print(f"    Service: {port_info['name']}")
            print(f"    Version: {port_info.get('version', 'N/A')}")
            print(f"    Product: {port_info.get('product', 'N/A')}")
            print(f"    Extra Info: {port_info.get('extrainfo', 'N/A')}")
    if 'osclass' in result:
        for osclass in result['osclass']:
            print(f"  OS Class: {osclass['osfamily']} {osclass['osgen']} ({osclass['type']})")
            print(f"    Accuracy: {osclass['accuracy']}%")
    if 'osmatch' in result:
        for osmatch in result['osmatch']:
            print(f"  OS Match: {osmatch['name']}")
            print(f"    Accuracy: {osmatch['accuracy']}%")

# Example output:
# Host: 10.11.1.1
#   Port: 80
#     State: open
#     Service: http
#     Version: 1.1
#     Product: Apache httpd
#     Extra Info: Ubuntu
#   OS Class: Linux 3.X (general purpose)
#     Accuracy: 98%
#   OS Match: Linux 3.2 - 4.9
#     Accuracy: 98%