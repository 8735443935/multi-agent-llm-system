import nmap
import sys

def perform_web_scan(hosts):
    web_ports = '80,443,8000,8080,8443'
    scan_arguments = '-sV -O --script=http-title,http-server-header'
    
    nm = nmap.PortScanner()
    
    for host in hosts:
        print(f"\n{'='*50}\nScanning {host}\n{'='*50}")
        try:
            # Perform detailed scan with OS detection and service versioning
            nm.scan(hosts=host, ports=web_ports, arguments=scan_arguments)
        except nmap.PortScannerError as e:
            print(f"Error scanning {host}: {str(e)}", file=sys.stderr)
            continue
        
        if host not in nm.all_hosts():
            print(f"Host {host} is down or unresponsive")
            continue
        
        host_info = nm[host]
        if host_info['status']['state'] != 'up':
            print(f"Host {host} is down")
            continue
        
        # OS Detection Results
        os_info = "Could not be determined"
        if 'osmatch' in host_info:
            if host_info['osmatch']:
                best_os = host_info['osmatch'][0]
                os_info = f"{best_os['name']} (Accuracy: {best_os['accuracy']}%)"
        
        # Service Information
        services = []
        for proto in host_info.all_protocols():
            for port in host_info[proto]:
                service = host_info[proto][port]
                services.append({
                    'port': port,
                    'protocol': proto,
                    'name': service['name'],
                    'product': service.get('product', 'N/A'),
                    'version': service.get('version', 'N/A'),
                    'extrainfo': service.get('extrainfo', 'N/A')
                })
        
        # Print results
        print(f"\nHost: {host}")
        print(f"OS Detection: {os_info}")
        print("\nWeb Services Found:")
        for service in services:
            print(f"Port {service['port']}/{service['protocol']}: {service['name']}")
            print(f"  Service: {service['product']} {service['version']}")
            print(f"  Extra Info: {service['extrainfo']}\n")

if __name__ == "__main__":
    target_hosts = ['10.11.1.0', '10.11.1.1', '10.11.1.24', '10.11.1.33']
    perform_web_scan(target_hosts)