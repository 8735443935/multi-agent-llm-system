#!/bin/bash
sudo lynis audit system --quick --no-updates